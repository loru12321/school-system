智慧教务管理系统 Windows 启动包

1. 解压本压缩包。
2. 双击“启动智慧教务管理系统.cmd”。
3. 系统会优先用 Edge/Chrome 的应用窗口打开 https://schoolsystem.com.cn/。
4. 后续更新只需要从“应用服务 / 应用下载中心”重新下载最新包。
